![SamaGames](https://assets.samagames.net/images/logo.png "SamaGames logo")

## SamaGames - RendLargen

Ce projet vous est mis a disposition dans une volonté de partage suite à la fermeture du serveur Minecraft [**SamaGames**](http://samagames.net).

Ce logiciel est publié sous licence GNU GPL version 3. Vous pouvez télécharger, modifier ou redistribuer — même commercialement — ce logiciel librement, tant que vous *précisez les changements apportés* et que vous *redistribuez vos modifications sous la même licence* (avec le code source), sans oublier de *préciser que votre travail est une reprise de ce projet de SamaGames*.
Pour plus de détails, référez-vous au texte de licence disponible [ici](LICENCE).

------------------------------------

- Nom : RendLargen
- Type : Infrastructure
- État : Terminé
- Développeur(s) : BlueSlime
- CDC (Si existant) : 


## Description
RendLargen est le projet permettant le traitement des achats sur la boutique en ligne du serveur.
