![SamaGames](https://assets.samagames.net/images/logo.png "SamaGames logo")

## SamaGames - KTP2017²

Ce projet vous est mis a disposition dans une volonté de partage suite à la fermeture du serveur Minecraft [**SamaGames**](http://samagames.net).

Ce logiciel est publié sous licence GNU GPL version 3. Vous pouvez télécharger, modifier ou redistribuer — même commercialement — ce logiciel librement, tant que vous *précisez les changements apportés* et que vous *redistribuez vos modifications sous la même licence* (avec le code source), sans oublier de *préciser que votre travail est une reprise de ce projet de SamaGames*.
Pour plus de détails, référez-vous au texte de licence disponible [ici](LICENCE).

------------------------------------

- Nom : KTP2017²
- Type : Mini-Jeu
- État : Terminé
- Développeur(s) : zyuiop (à l'origine), Vialonyx
- CDC (Si existant) : [KTP2017²](https://samagames.net/ressources/ktp2017-2.pdf)


## Description
KTP2017 est l'adaptation d'un concept de Maruku_Sama lui même inspiré par une série Youtube, KillThePatrick. Cette version est la remise à neuf de la version de zyuiop.
