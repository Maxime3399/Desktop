![SamaGames](https://assets.samagames.net/images/logo.png "SamaGames logo")

## SamaGames - Site internet de fermeture

Ce projet vous est mis a disposition dans une volonté de partage suite à la fermeture du serveur Minecraft [**SamaGames**](http://samagames.net).

Ce code est publié sous licence GNU GPL version 3. Vous pouvez télécharger, modifier ou redistribuer — même commercialement — ce code librement, tant que vous *précisez les changements apportés* et que vous *redistribuez vos modifications sous la même licence* (avec le code source), sans oublier de *préciser que votre travail est une reprise de ce projet de SamaGames*.
Pour plus de détails, référez-vous au texte de licence disponible [ici](LICENCE).

------------------------------------

- Nom : Site internet de fermeture
- Type : Site internet
- État : Terminé
- Développeur(s) : Reelwens
- CDC (Si existant) :


## Description
Le site internet de fermeture met à disposition de tous les projets réalisés par l'équipe de SamaGames, et permet la clôture officielle du serveur Minecraft.