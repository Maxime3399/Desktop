![SamaGames](https://assets.samagames.net/images/logo.png "SamaGames logo")

## SamaGames - Absorption

Ce projet vous est mis a disposition dans une volont� de partage suite � la fermeture du serveur Minecraft [**SamaGames**](http://samagames.net).

Ce logiciel est publi� sous licence GNU GPL version 3. Vous pouvez t�l�charger, modifier ou redistribuer � m�me commercialement � ce logiciel librement, tant que vous *pr�cisez les changements apport�s* et que vous *redistribuez vos modifications sous la m�me licence* (avec le code source), sans oublier de *pr�ciser que votre travail est une reprise de ce projet de SamaGames*.
Pour plus de d�tails, r�f�rez-vous au texte de licence disponible [ici](LICENCE).

------------------------------------

- Nom : Absorption
- Type : Mini-Jeu
- �tat : Non termin�
- D�veloppeur(s) : AmauryPi, 6infinity8
- CDC (Si existant) :


## Description
Absorption est un projet visant � reproduire Splatoon dans Minecraft. 