package net.samagames.persistanceapi.beans.statistics;

/*
 * This file is part of PersistanceAPI.
 *
 * PersistanceAPI is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * PersistanceAPI is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with PersistanceAPI.  If not, see <http://www.gnu.org/licenses/>.
 */
public class LeaderboardBean
{
    // Defines
    private String name;
    private int score;

    // Constructor
    public LeaderboardBean(String name, int score)
    {
        this.name = name;
        this.score = score;
    }

    // Getters
    public String getName() { return name; }
    public Integer getScore() { return score; }

    // Setters
    public void setName(String name) { this.name = name; }
    public void setScore(Integer score) { this.score = score; }
}
