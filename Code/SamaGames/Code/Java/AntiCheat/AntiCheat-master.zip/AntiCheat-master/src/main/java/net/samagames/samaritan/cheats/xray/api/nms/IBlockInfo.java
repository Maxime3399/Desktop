/**
 * @author Aleksey Terzi
 *
 */

package net.samagames.samaritan.cheats.xray.api.nms;

public interface IBlockInfo {
    int getX();
    int getY();
    int getZ();
    int getTypeId();
}