/**
 * @author Aleksey Terzi
 *
 */

package net.samagames.samaritan.cheats.xray.chunkmap;

public class ChunkLayer {
    public boolean hasData;
    public int[] map;
}