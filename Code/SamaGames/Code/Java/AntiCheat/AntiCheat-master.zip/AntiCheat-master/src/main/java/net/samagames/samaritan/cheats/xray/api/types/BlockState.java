/**
 * @author Aleksey Terzi
 *
 */

package net.samagames.samaritan.cheats.xray.api.types;

public class BlockState {
    public int id;
    public int meta;
}