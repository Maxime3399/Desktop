#!/bin/bash

scp target/*.jar amaurypi@aperture.samagames.net:~/updates/plugins/
